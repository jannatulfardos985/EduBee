require("dotenv").config();
const mongoose = require("mongoose");
const Course = require("./models/Course");
const Quiz = require("./models/Quiz");

const MONGO_URI = process.env.MONGO_URI || "mongodb://127.0.0.1:27017/jannat";

const coursesData = [
  {
    title: "Web Development",
    description: "Learn HTML, CSS, JavaScript, and modern web frameworks.",
    thumbnail: "https://img.icons8.com/color/452/web-design.png",
  },
  {
    title: "Graphic Design",
    description: "Master Photoshop, Illustrator, and visual communication.",
    thumbnail: "https://img.icons8.com/color/452/design.png",
  },
  {
    title: "Programming Fundamentals",
    description: "Learn data types, loops, functions, and problem-solving.",
    thumbnail: "https://img.icons8.com/color/452/source-code.png",
  },
  {
    title: "UI/UX Design",
    description: "Principles of user experience and interface design.",
    thumbnail: "https://img.icons8.com/color/452/design.png",
  },
  {
    title: "Cybersecurity Basics",
    description: "Learn threat analysis, encryption, and network protection.",
    thumbnail: "https://img.icons8.com/color/452/security-checked.png",
  },
];

const quizzesData = {
  "Web Development": [
    {
      title: "HTML Basics",
      question: "What does HTML stand for?",
      options: ["HyperText Markup Language", "HighText Machine Language", "Hyperloop Machine Language"],
      answer: 0,
    },
    {
      title: "HTML Images",
      question: "Which tag is used to display an image?",
      options: ["<image>", "<img>", "<src>"],
      answer: 1,
    },
  ],

  "Graphic Design": [
    {
      title: "Photoshop Use",
      question: "Photoshop is mainly used for?",
      options: ["Code editing", "Image editing", "3D rendering"],
      answer: 1,
    },
    {
      title: "Vector Tool",
      question: "Which tool is used to draw vector graphics?",
      options: ["Illustrator", "Notepad", "Premiere Pro"],
      answer: 0,
    },
  ],

  "Programming Fundamentals": [
    {
      title: "Python Print",
      question: "What is the correct syntax to print text in Python?",
      options: ["echo()", "printf()", "print()"],
      answer: 2,
    },
    {
      title: "JS Type",
      question: "What type of language is JavaScript?",
      options: ["Markup", "Styling", "Programming"],
      answer: 2,
    },
  ],

  "UI/UX Design": [
    {
      title: "UX Full Form",
      question: "UX stands for?",
      options: ["User Xperience", "User Experience", "Universal Experience"],
      answer: 1,
    },
  ],

  "Cybersecurity Basics": [
    {
      title: "Password Security",
      question: "What is used to protect stored passwords?",
      options: ["Hashing", "Copying", "Rewriting"],
      answer: 0,
    },
  ],
};

async function seed() {
  try {
    await mongoose.connect(MONGO_URI);
    console.log("MongoDB connected...");

    await Course.deleteMany();
    await Quiz.deleteMany();

    console.log("Old data cleared.");

    for (let courseData of coursesData) {
      const course = await Course.create(courseData);

      const quizList = quizzesData[course.title] || [];

      for (let q of quizList) {
        await Quiz.create({
          title: q.title,         // 🔥 important fix
          course: course._id,
          question: q.question,
          options: q.options,
          answer: q.answer,
        });
      }

      console.log(`Inserted course + quizzes: ${course.title}`);
    }

    console.log("Seeding completed!");
    process.exit();
  } catch (error) {
    console.error(error);
    process.exit(1);
  }
}

seed();

