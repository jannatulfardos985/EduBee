// server.js
require("dotenv").config();
const express = require("express");
const cors = require("cors");
const connectDB = require("./config/db");

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 5000;
const MONGO_URI = process.env.MONGO_URI || "mongodb://127.0.0.1:27017/jannat";

connectDB(MONGO_URI);

// Routes
app.use("/api/auth", require("./routes/auth"));
app.use("/api/users", require("./routes/users"));
app.use("/api/courses", require("./routes/courses"));
app.use("/api/enrollments", require("./routes/enrollments"));
app.use("/api/quiz", require("./routes/quiz"));

app.get("/", (req, res) => res.send({ status: "ok", msg: "Learning backend running" }));

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
