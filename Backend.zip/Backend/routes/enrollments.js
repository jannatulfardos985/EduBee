const express = require("express");
const auth = require("../middleware/auth");
const Enrollment = require("../models/Enrollment");

const router = express.Router();

// ENROLL user
router.post("/:courseId", auth, async (req, res) => {
  try {
    const userId = req.user.id;
    const courseId = req.params.courseId;

    const exists = await Enrollment.findOne({ user: userId, course: courseId });
    if (exists) return res.status(400).json({ error: "Already enrolled" });

    const enroll = new Enrollment({ user: userId, course: courseId });
    await enroll.save();

    res.status(201).json({ message: "Enrolled successfully", enrollment: enroll });
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
});

// CHECK enrollment
router.get("/check/:courseId", auth, async (req, res) => {
  try {
    const exists = await Enrollment.findOne({
      user: req.user.id,
      course: req.params.courseId
    });

   return res.json({ enrolled: !!exists });
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
});

// GET my enrolled courses
router.get("/my", auth, async (req, res) => {
  try {
    const enrolled = await Enrollment.find({ user: req.user.id })
      .populate("course");

    res.json(enrolled);
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
});

module.exports = router;



