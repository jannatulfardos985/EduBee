// routes/courses.js
const express = require("express");
const auth = require("../middleware/auth");
const Course = require("../models/Course");

const router = express.Router();

// GET /api/courses  - list all courses
router.get("/", async (req, res) => {
  try {
    const courses = await Course.find().populate("instructor", "name email");
    res.json(courses);
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
});

// GET /api/courses/:id - course details
router.get("/:id", async (req, res) => {
  try {
    const course = await Course.findById(req.params.id).populate("instructor", "name email");
    if (!course) return res.status(404).json({ error: "Course not found" });
    res.json(course);
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
});

// POST /api/courses  - create course (protected; ideally only instructor/admin)
router.post("/", auth, async (req, res) => {
  try {
    const { title, description } = req.body;
    if (!title) return res.status(400).json({ error: "Title is required" });

    const course = new Course({ title, description, instructor: req.user.id });
    await course.save();
    res.status(201).json(course);
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
});

// PUT /api/courses/:id - update course (protected)
router.put("/:id", auth, async (req, res) => {
  try {
    const { title, description } = req.body;
    const course = await Course.findById(req.params.id);
    if (!course) return res.status(404).json({ error: "Course not found" });

    // basic permission: only the instructor or admin should edit (not enforced fully here)
    if (course.instructor.toString() !== req.user.id) {
      // you could check user's role here; simple check for now:
      // allow if instructor matches
      return res.status(403).json({ error: "Not authorized to update this course" });
    }

    course.title = title || course.title;
    course.description = description || course.description;
    await course.save();
    res.json(course);
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
});

// DELETE /api/courses/:id - delete course (protected)
router.delete("/:id", auth, async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    if (!course) return res.status(404).json({ error: "Course not found" });
    if (course.instructor.toString() !== req.user.id) {
      return res.status(403).json({ error: "Not authorized to delete this course" });
    }
    await course.remove();
    res.json({ msg: "Course removed" });
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
});

module.exports = router;
