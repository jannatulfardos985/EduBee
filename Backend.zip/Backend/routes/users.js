const express = require("express");
const auth = require("../middleware/auth");
const User = require("../models/User");
const Enrollment = require("../models/Enrollment");

const router = express.Router();

// GET /api/users/me → returns logged-in user + enrollments
router.get("/me", auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select("-password");
    if (!user) return res.status(404).json({ error: "User not found" });

    // get enrollments
    const enrollments = await Enrollment.find({ user: req.user.id }).populate("course");

    res.json({
      ...user._doc,
      enrollments: enrollments.map(e => ({
        id: e._id,
        course: e.course
      }))
    });
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
});

module.exports = router;

