// routes/quiz.js
const express = require("express");
const auth = require("../middleware/auth");
const Quiz = require("../models/Quiz");
const Course = require("../models/Course");
const Result = require("../models/Result");
const Enrollment = require("../models/Enrollment");

const router = express.Router();

// POST /api/quiz/course/:courseId  - create quiz for a course (protected)
router.post("/course/:courseId", auth, async (req, res) => {
  try {
    const course = await Course.findById(req.params.courseId);
    if (!course) return res.status(404).json({ error: "Course not found" });

    // Only instructor of that course may create in production; here we simply allow
    const { title, questions } = req.body;
    if (!title || !questions || !Array.isArray(questions)) return res.status(400).json({ error: "Invalid payload" });

    // Basic validation of questions
    for (const q of questions) {
      if (!q.question || !Array.isArray(q.options) || typeof q.correctIndex !== "number") {
        return res.status(400).json({ error: "Invalid question format" });
      }
    }

    const quiz = new Quiz({ course: course._id, title, questions });
    await quiz.save();
    res.status(201).json(quiz);
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
});

// GET /api/quiz/course/:courseId - get all quizzes for a course
router.get("/course/:courseId", auth, async (req, res) => {
  try {
    const quizzes = await Quiz.find({ course: req.params.courseId });
    res.json(quizzes);
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
});

// GET /api/quiz/:quizId - get quiz (questions will be sent but DO NOT include correctIndex to client)
router.get("/:quizId", auth, async (req, res) => {
  try {
    const quiz = await Quiz.findById(req.params.quizId);
    if (!quiz) return res.status(404).json({ error: "Quiz not found" });

    // Enforce enrollment before allowing to take quiz
    const enrolled = await Enrollment.findOne({ user: req.user.id, course: quiz.course });
    if (!enrolled) return res.status(403).json({ error: "You must enroll to take this quiz" });

    // Remove correctIndex before sending
    const safeQuestions = quiz.questions.map(q => ({
      _id: q._id,
      question: q.question,
      options: q.options
    }));

    res.json({ _id: quiz._id, course: quiz.course, title: quiz.title, questions: safeQuestions });
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
});

// POST /api/quiz/:quizId/submit - submit answers { answers: [{ questionId, selectedIndex }, ...] }
router.post("/:quizId/submit", auth, async (req, res) => {
  try {
    const quiz = await Quiz.findById(req.params.quizId);
    if (!quiz) return res.status(404).json({ error: "Quiz not found" });

    // enrollment check
    const enrolled = await Enrollment.findOne({ user: req.user.id, course: quiz.course });
    if (!enrolled) return res.status(403).json({ error: "You must enroll to submit this quiz" });

    const answers = req.body.answers;
    if (!Array.isArray(answers)) return res.status(400).json({ error: "Answers are required" });

    // compute score
    let score = 0;
    for (const ans of answers) {
      const q = quiz.questions.id(ans.questionId);
      if (!q) continue;
      if (q.correctIndex === ans.selectedIndex) score++;
    }
    const total = quiz.questions.length;

    // Save result
    const result = new Result({
      user: req.user.id,
      course: quiz.course,
      quiz: quiz._id,
      score,
      total
    });
    await result.save();

    res.json({ score, total, resultId: result._id });
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
});

module.exports = router;
